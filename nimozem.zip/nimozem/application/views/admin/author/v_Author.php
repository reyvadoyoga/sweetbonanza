<!DOCTYPE html>
<html lang="en">
    <head>
        <?php $this->load->view("admin/_partials/head.php") ?>   
    </head>

    <body class="sb-nav-fixed">
        <?php $this->load->view("admin/_partials/navbar.php") ?>
        
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                    <?php $this->load->view("admin/_partials/sidebar.php") ?>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                    <h1 class="mt-4">Author</h1>
                        <?php $this->load->view("admin/_partials/breadcrumb.php") ?>
                        
                    
                        <!----/.box-header ------>
                        <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table mr-1"></i>DataTable Example
                            <a type="button" data-bs-toggle="modal" data-bs-target="#addAuthor" class="btn btn-primary">
                                Add (+)
                            </a>
                        </div>

                        <div class="card-body">
                            <div class="table-responsive">
                            <table class="table table-bordered" id="datatablesSimple" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Fullname</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $x=1;
                                    foreach ($author->result_array() as $i) :
                                    $id = $i['author_id'];
                                    $fullname = $i['fullname'];
                                    $email = $i['email'];
                                ?>
                                <tr>
                                    <td> <?php echo $x; ?> </td>
                                    <td> <?php echo $fullname; ?> </td>
                                    <td> <?php echo $email; ?> </td>
                                    <td>
                                        <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editAuthor<?php echo $id; ?>">Edit</a>
                                        <a type="button" data-bs-toggle="modal" data-bs-target="#deleteAuthor<?php echo $id; ?>"class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                                <?php
                                $x++;
                            endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $this->load->view("admin/_partials/footer.php") ?>
</div>
</div>
</body>
<?php $this->load->view("admin/author/modal_author.php") ?>
<?php $this->load->view("admin/_partials/modal.php") ?>
<?php $this->load->view("admin/_partials/js.php") ?>
<script src="<?php echo base_url('js/datatables-simple-demo.js') ?>"></script>
</html>