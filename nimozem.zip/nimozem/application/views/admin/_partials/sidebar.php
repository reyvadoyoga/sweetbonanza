<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav <?php echo $this->uri->segment(2) == '' ? 'active' : '' ?>">
            <div class="sb-sidenav-menu-heading text-success">Core</div>
            <a class="nav-link" href="<?= base_url('admin/overview') ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Dashboard
            </a>

            <div class="collapse" id="collapseLayouts2" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                <nav class="sb-sidenav-menu-nested nav">
                </div>

                <div class="sb-sidenav-menu-heading text-success">Barang</div>
                <a class="nav-link" href="<?= base_url('admin/Book') ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-balance-scale"></i></div>
                    Stok Barang
                </a>

                <div class="sb-sidenav-menu-heading text-success">Transaksi</div>
                <a class="nav-link" href="<?= base_url('admin/Penjualan') ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-balance-scale"></i></div>
                    Penjualan
                </a>
                <a class="nav-link" href="<?php echo site_url('admin/penjualan/list_penjualan')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Laporan Penjualan
                </a>
                <a class="nav-link" href="<?php echo site_url('admin/penjualan/chart')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Chart Penjualan
                </a>
                <a class="nav-link" href="<?php echo base_url('admin/Pembelian')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-piggy-bank"></i></div>
                    Pembelian
                </a>
                <a class="nav-link" href="<?php echo site_url('admin/pembelian/list_pembelian')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Laporan Pembelian
                </a>
                <a class="nav-link" href="<?php echo site_url('admin/pembelian/chart')?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Chart Pembelian
                </a>
            </a>
        </div>
    </div>
    <div class="sb-sidenav-footer">
        <div class="small">Logged in as:</div>
        User
    </div>
</a>
</a>
</a>
</a>
</nav>