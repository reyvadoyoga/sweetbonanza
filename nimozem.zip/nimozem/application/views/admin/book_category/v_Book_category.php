<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body class="sb-nav-fixed">
    <?php $this->load->view("admin/_partials/navbar.php") ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php $this->load->view("admin/_partials/sidebar.php") ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h1 class="mt-4">Masker Category</h1>
                    <?php $this->load->view("admin/_partials/breadcrumb.php") ?>
                    <div class="card mb-4">
                        <div class="card-header"><i class="fas fa-table mr-1"></i> Data Table Masker_category
                            <a type="button" data-bs-toggle="modal" data-bs-target="#addBook_category" class="btn btn-primary">
                                Add (+)
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="datatablesSimple" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $x = 1;
                                        foreach ($Book_category->result_array() as $i) :
                                            $id = $i['book_category_id'];
                                            $name = $i['name'];
                                            ?>
                                            <tr>
                                                <td><?php echo $x; ?></td>
                                                <td><?php echo $name; ?></td>
                                                <td>
                                                    <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editBook_category<?= $id; ?>">Edit</a>
                                                    <a class="btn btn-danger" type="button" data-bs-toggle="modal" data-bs-target="#deleteBook_category<?= $id; ?>">Delete</a>
                                                </td>
                                            </tr>
                                            <?php
                                            $x++;
                                        endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <?php $this->load->view("admin/_partials/footer.php") ?>
        </div>
    </div>
    
    <!-- Modal -->
    <?php $this->load->view("admin/book_category/modal_book_category.php") ?>
    <?php $this->load->view("admin/_partials/modal.php") ?>

    <!-- JavaScript -->
    <?php $this->load->view("admin/_partials/js.php") ?>
    <?php $this->load->view("admin/_partials/modal.php") ?>
</body>

</html>