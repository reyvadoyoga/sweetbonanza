<div class="modal fade" id="addBook" role="dialog">
	<div class="modal-dialog">
		<form class="from" action="<?= base_url('admin/book/add'); ?>" method="POST">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Add Barang</h5>
					<button type="button" calass="close" data-bs-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-lable">Nama Barang</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="i_title" placeholder="Nama Barang" required>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-lable">Price</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="i_price" placeholder="Price" required>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-lable">Discount</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="i_discount" placeholder="Discount" required>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-lable">Stock</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="i_stock" placeholder="Stock" required>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-foter">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
					<button type="submit" class="btn btn-primary">Add</button>
				</div>
			</div>
		</form>
	</div>
</div>


<?php
foreach ($book->result_array() as $i) :
	$id = $i['book_id'];
	$title = $i['title'];
	$price = $i['price'];
	$discount = $i['discount'];
	$stock = $i['stock'];
	?>
	<div class="modal fade" id="editBook<?= $id; ?>" role="dialog">
		<div class="modal-dialog">	
			<form class="form" action="<?= base_url ('admin/Book/edit'. $id); ?>" method="POST">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Edit Barang</h5>
						<button type="button" class="close" data-bs-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Nama Barang</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="i_title" placeholder="Merek" value="<?= $title; ?>">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Price</label>
								<div class="col-sm-10">
									<input type="int" class="form-control" name="i_price" placeholder="Price" value="<?= $price; ?>">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Diskon</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="i_discount" placeholder="jl.Babarsari" value="<?= $discount; ?>">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Stock</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="i_stock" placeholder="Stock" value="<?= $stock; ?>">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
						<button type="submit" class="btn btn-primary">Edit</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<?php
endforeach;
?>


<?php
foreach ($book->result_array() as $i) :
	$id = $i['book_id'];
	$title = $i['title'];
	$price = $i['price'];
	$discount = $i['discount'];
	$stock = $i['stock'];

	?>
	<div class="modal fade" id="deleteBook<?= $id; ?>" role="dialog">
		<div class="modal-dialog">
			<form class="form" action="<?= base_url ('admin/Book/delete'. $id); ?>" method="POST">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ready to Delete Barang?</h5>
						<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">x</span>
						</button>
					</div>
					<div class="modal-body">
						Pilih "Delete" untuk menghapus Barang dengan nama <b><?= $title; ?></b>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
						<button type="submit" class="btn btn-primary">Delete</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<?php
endforeach;
?>