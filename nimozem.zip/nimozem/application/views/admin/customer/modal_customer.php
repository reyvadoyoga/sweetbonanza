<div class="modal fade" id="addCustomer" role="dialog">
	<div class="modal-dialog">	
		<form class="form" action="<?= base_url ('admin/customer/add'); ?>" method="POST">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Add Customer</h5>
					<button type="button" class="close" data-bs-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<div class= "row">
							<label for="title" class="col-sm-2 control-label">Customer Name</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="i_name" placeholder="Mark Zurkerburg">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-label">Email</label>
							<div class="col-sm-10">
								<input type="email" class="form-control" name="i_email" placeholder="markzurkerburg@gmial.com">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-label">No Member</label>
							<div class="col-sm-10">
								<input type="var" class="form-control" name="i_no_member" placeholder="A123">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-label">Gender</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="i_gender" placeholder="Laki-laki/Perempuan">
							</div>
						</div>
					</div>
				<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-label">Phone</label>
							<div class="col-sm-10">
								<input type="int" class="form-control" name="i_phone" placeholder="08123456789">
							</div>
						</div>
					</div>
				<div class="form-group">
						<div class="row">
							<label for="title" class="col-sm-2 control-label">Address</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="i_address" placeholder="jl.Babarsari">
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
					<button type="submit" class="btn btn-primary">Add</button>
				</div>
			</div>
		</form>
	</div>
</div>

<?php
foreach ($customer->result_array() as $i):
	$id = $i['customer_id'];
	$name = $i['name'];
	$email = $i['email'];
	$no_member = $i['no_member'];
	$gender = $i['gender'];
	$phone = $i['phone'];
	$address = $i['address'];
?>
	<div class="modal fade" id="editCustomer<?= $id; ?>" role="dialog">
		<div class="modal-dialog">	
			<form class="form" action="<?= base_url ('admin/customer/edit/'. $id); ?>" method="POST">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Edit Customer</h5>
						<button type="button" class="close" data-bs-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Customer Name</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="i_name" placeholder="Mark Zurkerburg" value="<?= $name; ?>">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Email</label>
								<div class="col-sm-10">
									<input type="email" class="form-control" name="i_email" placeholder="markzurkerburg@gmail.com" value="<?= $email; ?>">
								</div>
							</div>
						</div>
					<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">No Member</label>
								<div class="col-sm-10">
									<input type="var" class="form-control" name="i_no_member" placeholder="A123" value="<?= $no_member; ?>">
								</div>
							</div>
						</div>
					<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Gender</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="i_gender" placeholder="Laki-laki/Perempuan" value="<?= $gender; ?>">
								</div>
							</div>
						</div>
					<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Phone</label>
								<div class="col-sm-10">
									<input type="int" class="form-control" name="i_phone" placeholder="08123456789" value="<?= $phone; ?>">
								</div>
							</div>
						</div>
					<div class="form-group">
							<div class= "row">
								<label for="title" class="col-sm-2 control-label">Address</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="i_address" placeholder="jl.Babarsari" value="<?= $address; ?>">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
						<button type="submit" class="btn btn-primary">Edit</button>
					</div>
				</div>
			</form>
		</div>
	</div>
<?php
endforeach;
?>

<?php
foreach ($customer->result_array() as $i):
	$id = $i['customer_id'];
	$name = $i['name'];
	$email = $i['email'];
	$no_member = $i['no_member'];
	$gender = $i['gender'];
	$phone = $i['phone'];
	$address = $i['address'];
?>
	<div class="modal fade" id="deleteCustomer<?= $id; ?>" role="dialog">
		<div class="modal-dialog">
			<form class="form" action="<?= base_url ('admin/customer/delete/'. $id); ?>" method="POST">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ready to Delete Customer?</h5>
						<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">x</span>
						</button>
					</div>
					<div class="modal-body">
						Pilih "Delete" untuk menghapus Customer dengan nama <b><?= $name; ?></b>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
						<button type="submit" class="btn btn-primary">Delete</button>
					</div>
				</div>
			</form>
		</div>
	</div>
<?php
endforeach;
?>