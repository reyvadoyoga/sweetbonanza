<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body class="sb-nav-fixed">
    <?php $this->load->view("admin/_partials/navbar.php") ?>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <?php $this->load->view("admin/_partials/sidebar.php") ?>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h1 class="mt-4">Customer</h1>
                    <?php $this->load->view("admin/_partials/breadcrumb.php") ?>
                    <div class="card mb-4">
                        <div class="card-header"><i class="fas fa-table mr-1"></i> Data Table Customer
                            <a type="button" data-bs-toggle="modal" data-bs-target="#addCustomer" class="btn btn-primary">
                                Add (+)
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="datatablesSimple" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>No Member</th>
                                            <th>Gender</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $x = 1;
                                        foreach ($customer->result_array() as $i) :
                                            $id = $i['customer_id'];
                                            $name = $i['name'];
                                            $email = $i['email'];
                                            $no_member = $i['no_member'];
                                            $gender = $i['gender'];
                                            $phone = $i['phone'];
                                            $address = $i['address'];
                                        ?>
                                            <tr>
                                                <td><?php echo $x; ?></td>
                                                <td><?php echo $name; ?></td>
                                                <td><?php echo $email; ?></td>
                                                <td><?php echo $no_member; ?></td>
                                                <td><?php echo $gender; ?></td>
                                                <td><?php echo $phone; ?></td>
                                                <td><?php echo $address; ?></td>
                                                <td>
                                                    <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editCustomer<?= $id; ?>">Edit</a>
                                                    <a class="btn btn-danger" type="button" data-bs-toggle="modal" data-bs-target="#deleteCustomer<?= $id; ?>">Delete</a>
                                                </td>
                                            </tr>
                                        <?php
                                            $x++;
                                        endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <?php $this->load->view("admin/_partials/footer.php") ?>
        </div>
    </div>

    <!-- Modal -->
    <?php $this->load->view("admin/customer/modal_customer.php") ?>
    <?php $this->load->view("admin/_partials/modal.php") ?>
    <!-- JavaScript -->
    <?php $this->load->view("admin/_partials/js.php") ?>
    
</body>

</html>