<!DOCTYPE html>
<html lang="en">
	<head>
		<?php $this->load->view("admin/_partials/head.php") ?>
	</head>

	<body class="sb-nav-fixed">
		<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="layoutSidenav">
		<div id="layoutSidenav_nav">
		<?php $this->load->view("admin/_partials/sidebar.php") ?>
	</div>
	<div id="layoutSidenav_content">
		<main>
			<div class="container-fluid px-4">
				<h1 class="mt-4">Data Diri</h1>
				<o1 class="breadcrumb mb-4">
					<?php $this->load->view("admin/_partials/breadcrumb.php") ?>
				</o1>
				
				<p>Nama Lengkap				: Laurensius Ronaldo Satriayuda</p>
				<p>Nama Panggilan			: Yuda</p>
				<p>Tempat, Tanggal Lahir	: Jayapura, 14 Juli 2001</p>
				<p>Alamat					: Karangasem</p>
				<p>NPM						: 191710266</p>
				<p>Sosial Media				: laurensiusyuda</p>
				<p>Nomor Telepon			: 089505147173</p>
				<p>Hobi						: Olahraga</p>

			</div>
		</main>
			<?php $this->load->view("admin/_partials/footer.php") ?>
	</div>
</div>
<?php $this->load->view("admin/_partials/js.php") ?>
</body>
<?php $this->load->view("admin/_partials/modal.php") ?>
</html>