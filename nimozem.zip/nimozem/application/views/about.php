<!DOCTYPE html>
<html lang="en">
	<head>
		<?php $this->load->view("admin/_partials/head.php") ?>
	</head>

	<body class="sb-nav-fixed">
		<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="layoutSidenav">
		<div id="layoutSidenav_nav">
		<?php $this->load->view("admin/_partials/sidebar.php") ?>
	</div>
	<div id="layoutSidenav_content">
		<main>
			<div class="container-fluid px-4">
				<h1 class="mt-4">About</h1>
				<o1 class="breadcrumb mb-4">
					<?php $this->load->view("admin/_partials/breadcrumb.php") ?>
				</o1>
				
				<p>Halaman about</p>

			</div>
		</main>
			<?php $this->load->view("admin/_partials/footer.php") ?>
	</div>
</div>
<?php $this->load->view("admin/_partials/js.php") ?>
</body>
<?php $this->load->view("admin/_partials/modal.php") ?>
</html>