<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body class="sb-nav-fixed">
	<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="layoutSidenav">
		<div id="layoutSidenav_nav">
			<?php $this->load->view("admin/_partials/sidebar.php") ?>
		</div>
		<div id="layoutSidenav_content">
			<main>
				<div class="container-fluid px-4">
					<h1 class="mt-4">Container</h1>
					<o1 class="breadcrumb mb-4">
						<?php $this->load->view("admin/_partials/breadcrumb.php") ?>
					</o1>

					<div class="container">
						<div class="row">
							<div class="col-md-12 bg-warning"><h5><center><strong>Container 1 - Gambar</strong></center></h5></div>
						</div>
						<div class="row">
							<div class="col-md-4 pb-2 bg-info text-dark"><center><img src="<?php echo base_url('assets/img/UAJY-LOGOGRAM_-01.png'); ?>" width="200" height="250"></center>
								<center><b>Foto UAJY</b></center>
							</div>

							<div class="col-md-4 pb-2 bg-secondary text-dark"><center><img src="<?php echo base_url('assets/img/Foto_Diri.jpg'); ?>" width="250" height="250"></center>
								<center><b>Foto Diri</b></center>
							</div>

							<div class="col-md-4 pb-2 bg-success text-dark"><center><img src="<?php echo base_url('assets/img/Gedung-Bonaventura.jpg'); ?>" class="img-thumbnail mx-auto d-block" width="auto" height="auto"></center>
								<center><b>Foto Gedung Babarsari</b></center>
							</div>
						</div>
						<br>
						<div class="row">
							<div class="col bg-success"><h5><center><strong>Container 2 - Pesan dan Kesan</strong></center></h5></div>
						</div>
						<div class="row">
							<div class="col bg-info"><h5><p class="text-center">Pengalaman Belajar SIWEB</p></h5>
								<p class="text-center">Asik dan bikin pusing</p>
							</div>
							<div class="col bg-warning"><h5><p class="text-center">Kepada Dosen dan Asdos</p></h5>
								<p class="text-center">Semoga materi SIWEB setelah UTS tidak terlalu susah dan asodosnya tetap semangat ngajarin kita</p>
							</div>
						</div>
					</div>
				</div>
			</main>
			<?php $this->load->view("admin/_partials/footer.php") ?>
		</div>
	</div>
	<?php $this->load->view("admin/_partials/js.php") ?>
</body>
<?php $this->load->view("admin/_partials/modal.php") ?>
</html>