<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Examples2 extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');

		$this->load->library('grocery_CRUD');
	}

	public function _example2_output($output = null)
	{
		$this->load->view('example2.php',(array)$output);
	}

	public function index()
	{
		$this->_example2_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}

	public function author_management()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('datatables');
			$crud->set_table('author');
			$crud->set_subject('author');
			$crud->required_fields('author_id');
			$crud->columns('fullname','email');

			$output = $crud->render();

			$this->_example2_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function book_category_management()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('datatables');
			$crud->set_table('book_category');
			$crud->set_subject('book_category');
			$crud->required_fields('book_category_id');
			$crud->columns('name');

			$output = $crud->render();

			$this->_example2_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function supplier_management()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('datatables');
			$crud->set_table('supplier');
			$crud->set_subject('supplier');
			$crud->required_fields('book_category_id');
			$crud->columns('name','email','phone','address');

			$output = $crud->render();

			$this->_example2_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function customer_management()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('datatables');
			$crud->set_table('customer');
			$crud->set_subject('customer');
			$crud->required_fields('customer_id');
			$crud->columns('name','email','no_member','gender','phone','address');

			$output = $crud->render();

			$this->_example2_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	public function level_management()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('datatables');
			$crud->set_table('level');
			$crud->set_subject('level');
			$crud->required_fields('level_id');
			$crud->columns('name');

			$output = $crud->render();

			$this->_example2_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function book()
	{
		if($this->session->userdata('employee_id')!=null){

			$crud = new grocery_CRUD();
			$crud->set_table('book');

			$crud->set_relation_n_n('author','book_author','author','book_id','author_id','fullname');
			$crud->set_relation_n_n('category','book_bookcat','book_category','book_id','book_category_id','name');
			$crud->set_subject('book');
			$crud->columns('title','author','category','description','release_year','pages','price','stock');
			$output = $crud->render();
			$this->_example2_output($output);
		}else{
			echo '<script language=JavaScript>alert("Anda Bukan Employee, Silahkan Login")
			onclick-location.href="../auth/Employee"</script>';
		}
	}
}