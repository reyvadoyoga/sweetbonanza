<?php

class Overview extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('admin/overview');
	}

	public function about()
	{
		$this->load->view('about.php');
	}

	public function contact()
	{
		$this->load->view('contact.php');
	}

	public function biodata()
	{
		$this->load->view('biodata.php');
	}

	public function deskripsi()
	{
		$this->load->view('deskripsi.php');
	}

	public function pengalaman()
	{
		$this->load->view('pengalaman.php');
	}

	public function container()
	{
		$this->load->view('container.php');
	}
}