<?php defined ('BASEPATH') or exit('No direct script access allowed');
class Book_category extends CI_Controller
{
    public function __construct()
    {
        parent :: __construct();
        #load model, helper dan library
        $this->load->model('Book_category_model');
    }

    public function index()
    {
        $data['Book_category'] = $this->Book_category_model->book_category_getAll();
        $this->load->view('admin/Book_category/v_Book_category', $data);
    }

    public function add()
    {
        $name = strip_tags($this->input->post('i_name'));
        //Input array
        $data = array(
            'name' => $name
        );
        //Insert ke database
        $x = $this->Book_category_model->book_category_cek($name);
        if ($x == null) {
            $this->Book_category_model->book_category_insert('book_category', $data);

            echo '<script language=JavaScript>alert("Input Berhasil")
            onclick = location.href = document.referrer</script>';

        } else {

            echo '<script language=JavaScript>alert("Gagal!! Book_category telah tersimpan sebelumnya")
            onclick = history.go(-1)</script>';
        }
    }   

    public function edit($id)
    {
        $data['book_category'] = $this->Book_category_model->book_category_getById($id);
        $name = strip_tags($this->input->post('i_name'));
        //input array
        $data = array(
            'name' =>$name
        );
        //insert ke fbsql_database(link_identifier)
        $x = $this->Book_category_model->book_category_cek($name);
        if ($x == null) {
            $this->Book_category_model->book_category_update($id, 'book_category', $data);
            echo '<script language=JavaScript>alert("Update Berhasil")
            onclick = location.href = document.referrer</script>';
        } else {
            echo '<script language=JavaScript>alert("Gagal!! Book_category telah tersimpan sebelumnya")
            onclick = history.go(-1)</script>';
        }
    }

    public function delete($id)
    {
        $this->Book_category_model->book_category_delete('book_category',$id );
        echo '<script language=JavaScript>alert("Delete Berhasil")
        onclick = history.go(-1)</script>';
    }
}
?>