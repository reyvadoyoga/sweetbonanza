<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Employee extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Level_model');
    }

    public function index()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = "Login Admin";
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/loginEmployee');
            $this->load->view('templates/auth_footer', $data);
        } else {
            $this->_login();
        }
    }

    private function _login()
    {
        $email = $this->input->post('email');
        $password  = $this->input->post('password');

        $employee = $this->db->get_where('employee', ['email' => $email])->row();

        if ($employee) {
            if (password_verify($password, $employee->password)) {
                $data = [
                    'employee_id' => $employee->employee_id,
                    'email' => $employee->email,
                    'name' => $employee->name,
                    'level_id' => $employee->level_id,
                ];
                $this->session->set_userdata($data);
                redirect('admin/overview');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Salah!!</div>');
                redirect('auth/Employee');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Login Gagal!!</div>');
            redirect('auth/Employee');
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        $this->session->mark_as_flash('message', '<div class="alert alert-success" role="alert">Registrasi Telah Berhasil!!. Silahkan Login!</div>');
        redirect('auth/Admin');
    }
}
